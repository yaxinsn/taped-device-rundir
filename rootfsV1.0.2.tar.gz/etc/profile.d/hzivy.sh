TOPDIR="/home/root/rundir"
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${TOPDIR}/lib/:${TOPDIR}/usr/lib/"
export PATH="/usr/bin:/usr/sbin:/bin:/sbin:${TOPDIR}/bin/:${TOPDIR}/sbin/:${TOPDIR}/usr/bin/:${TOPDIR}/usr/sbin"
